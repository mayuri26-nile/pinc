
/*********************** Navigation Scetion ***********************/

$(document).ready(function(){
    $('.pinc-navbar-nav li .smooth-scroll').click(function(){
      $('li .smooth-scroll').removeClass("active");
      $(this).addClass("active");
  });
  });

//Show & Hide navigation bg

$(function () {

    $(window).scroll(function () {
        if ($(this).scrollTop() < 50) {
            //hide nav-bg
            $("nav").removeClass("vesco-top-nav");
            $("#back-to-top").fadeOut();
        } else {
            //show nav-bg
            $("nav").addClass("vesco-top-nav");
            $("#back-to-top").fadeIn();
        }
    });

});

/*********************** Team Scetion ***********************/

$(function () {
    $("#Market-members").owlCarousel({
        items: 4,
        autoplay: true,
        smartSpeed: 500,
        loop: true,
        responsiveClass:true,
        responsive:{
            320:{
                items:1
            },
            576:{
                items:2
            },
            760:{
                items:3
            },
            991:{
                items:4
            }
        }
    });
});

/*********************** Counter Scetion ***********************/


// $(function () {
//     $('.counter').counterUp({
//         delay: 10,
//         time: 3000
//     });
// });

/*********************** button on click ***********************/

// $(document).ready(function(){
//     $("c").click(function(){
//       $(".btn-general-Spotlight").addClass("focus");
//     });
//   });

//   $(document).ready(function(){
//     $(".btn-general-Spotlight-2").click(function(){
//       $(".btn-general-Spotlight-2").addClass("focus");
//     });
//   });


// $( function() {
//     $('.btn-general-Spotlight').click( function() {
//       $(this).css('background', '#aaa')
      
//     } );

//  $('.btn-general-Spotlight-2').click( function() {
//       $(this).css('background', '#aaa')
//  $('.btn-general-Spotlight').css('background', '#E0066D')
//     } );
//   } );

  $(document).ready(function(){
    $(".btn-general-Spotlight").click(function(){
      $('.btn-general-Spotlight').addClass('btn-click-bgchange');
      $('.btn-general-Spotlight-2').removeClass('btn-click-bgchange');
    });
    $(".btn-general-Spotlight-2").click(function(){
      $('.btn-general-Spotlight-2').addClass('btn-click-bgchange');
      $('.btn-general-Spotlight').removeClass('btn-click-bgchange');
    });
  });






















